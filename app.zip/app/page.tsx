// import Redirect from '@/components/Redirect'
import React from 'react'

const Home = () => {
  return (
    <div>
      {/* <Redirect /> */}
    </div>
  )
}

export default Home